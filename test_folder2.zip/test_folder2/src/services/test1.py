import boto3
import json

# Initialize the Bedrock client
client = boto3.client('bedrock-runtime', region_name='us-east-1')

# Define the model ARN
model_arn = 'arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-5-sonnet-20240620-v1:0'

# Define the input parameters with a detailed prompt
input_parameters = {
    "prompt": "Provide a detailed analysis of the financial performance of Barclays in H124 compared to H123. Include key metrics such as Total Income, NIM, CIR, and RoTE. Highlight any significant changes or trends.",
    "knowledge_base_id": "your-knowledge-base-id",
    "max_tokens": 8191
}

# Convert input parameters to JSON
body = json.dumps(input_parameters)

# Call the retrieve_and_generate function
response = client.retrieve_and_generate(
    modelId=model_arn,
    body=body,
    contentType='application/json',
    accept='application/json'
)

# Parse the response
response_body = json.loads(response['body'].read().decode())
print(response_body)