import streamlit as st
import json
import os
from typing import Dict

class AdminUI:
    def __init__(self, common_config: Dict, bank_configs: Dict):
        self.common_config = common_config
        self.bank_configs = bank_configs
        
    def render(self):
        """Render the Admin interface."""
        self._render_header()
        
        # Bank selector
        selected_bank = st.selectbox(
            "Select Bank",
            options=list(self.bank_configs.keys()),
            format_func=lambda x: self.bank_configs[x]['bank_info']['name']
        )

        if selected_bank:
            bank_config = self.bank_configs[selected_bank]
            self._render_bank_settings(selected_bank, bank_config)

    def _render_header(self):
        """Render admin header with back button."""
        col1, col2, col3 = st.columns([0.5, 10.5, 1])
        with col1:
            st.write("")
        with col2:
            st.markdown("### Admin Configuration")
        with col3:
            if st.button("← Back", key="admin_back", use_container_width=True):
                st.session_state.current_view = 'main'
                st.rerun()

    def _render_bank_settings(self, bank_id: str, bank_config: Dict):
        """Render settings for selected bank."""
        tabs = st.tabs([
            "General Settings",
            "Data Sources",
            "Metrics Configuration",
            "Prompt Templates"
        ])

        with tabs[0]:
            self._render_general_settings(bank_config)
        
        with tabs[1]:
            self._render_data_sources(bank_config)
        
        with tabs[2]:
            self._render_metrics_config(bank_config)
        
        with tabs[3]:
            self._render_prompt_config(bank_config)

        # Save changes button
        if st.button("Save Changes", type="primary"):
            try:
                self._save_bank_config(bank_id, bank_config)
                st.success("Changes saved successfully!")
            except Exception as e:
                st.error(f"Error saving changes: {str(e)}")

    def _render_general_settings(self, bank_config: Dict):
        """Render general bank settings."""
        st.subheader("General Settings")

        # Basic Information
        col1, col2 = st.columns(2)
        with col1:
            bank_config['bank_info']['name'] = st.text_input(
                "Bank Name",
                bank_config['bank_info']['name']
            )
        with col2:
            bank_config['bank_info']['logo_url'] = st.text_input(
                "Logo URL",
                bank_config['bank_info']['logo_url']
            )

        # Implementation Status
        bank_config['bank_info']['implementation_status'] = st.selectbox(
            "Implementation Status",
            options=['pending', 'active', 'deprecated'],
            index=['pending', 'active', 'deprecated'].index(
                bank_config['bank_info']['implementation_status']
            )
        )

        # Theme Colors
        st.subheader("Theme Colors")
        col1, col2, col3 = st.columns(3)
        with col1:
            bank_config['bank_info']['theme_colors']['primary'] = st.color_picker(
                "Primary Color",
                bank_config['bank_info']['theme_colors']['primary']
            )
        with col2:
            bank_config['bank_info']['theme_colors']['secondary'] = st.color_picker(
                "Secondary Color",
                bank_config['bank_info']['theme_colors']['secondary']
            )
        with col3:
            bank_config['bank_info']['theme_colors']['header'] = st.color_picker(
                "Header Color",
                bank_config['bank_info']['theme_colors']['header']
            )

    def _render_data_sources(self, bank_config: Dict):
        """Render data source configuration."""
        st.subheader("File Configurations")

        for i, file_config in enumerate(bank_config['file_config']['files']):
            with st.expander(f"File Configuration {i+1}", expanded=True):
                col1, col2 = st.columns(2)
                with col1:
                    file_config['path'] = st.text_input(
                        "File Path",
                        file_config['path'],
                        key=f"file_path_{i}"
                    )
                with col2:
                    file_config['sheet_name'] = st.text_input(
                        "Sheet Name",
                        file_config['sheet_name'],
                        key=f"sheet_name_{i}"
                    )

        if st.button("Add New File Configuration"):
            bank_config['file_config']['files'].append({
                'path': '',
                'sheet_name': '',
                'type': 'primary'
            })

    def _render_metrics_config(self, bank_config: Dict):
        """Render metrics configuration."""
        st.subheader("Metrics Configuration")

        for dataset_name, dataset_config in bank_config['datasets'].items():
            with st.expander(f"{dataset_name} Configuration", expanded=True):
                self._render_dataset_config(dataset_config)

    def _render_dataset_config(self, dataset_config: Dict):
        """Render configuration for a specific dataset."""
        # Column mappings
        st.subheader("Column Mappings")
        for column_name, source_col in dataset_config['columns'].items():
            col1, col2 = st.columns(2)
            with col1:
                st.text(column_name)
            with col2:
                dataset_config['columns'][column_name] = st.text_input(
                    "Source Column",
                    source_col,
                    key=f"col_map_{column_name}"
                )

        # Metrics
        st.subheader("Metrics")
        for i, metric in enumerate(dataset_config['metrics']):
            col1, col2, col3 = st.columns(3)
            with col1:
                metric['name'] = st.text_input(
                    "Metric Name",
                    metric['name'],
                    key=f"metric_name_{i}"
                )
            with col2:
                metric['source'] = st.text_input(
                    "Source",
                    metric.get('source', ''),
                    key=f"metric_source_{i}"
                )
            with col3:
                if st.button("Remove", key=f"remove_metric_{i}"):
                    dataset_config['metrics'].remove(metric)

        if st.button("Add New Metric"):
            dataset_config['metrics'].append({
                'name': 'New Metric',
                'source': '',
                'calculation': 'direct'
            })

    def _render_prompt_config(self, bank_config: Dict):
        """Render prompt template configuration."""
        st.subheader("Prompt Template")
        
        bank_config['prompt']['template'] = st.text_area(
            "Template",
            bank_config['prompt']['template'],
            height=400
        )

        st.info("""
        Available variables:
        - {bank_name}: Bank name
        - {data}: The source data
        - {calculation_rules}: Metric calculation rules
        """)

    def _save_bank_config(self, bank_id: str, bank_config: Dict):
        """Save bank configuration to file."""
        config_path = f'config/banks/{bank_id}_config.json'
        with open(config_path, 'w') as f:
            json.dump(bank_config, f, indent=2)