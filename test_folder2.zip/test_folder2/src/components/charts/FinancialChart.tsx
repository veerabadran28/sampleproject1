import React from 'react';
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, AreaChart, Area,
  ComposedChart, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis, 
  PolarRadiusAxis
} from 'recharts';

const COLORS = ['#0051A2', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

const formatValue = (value) => {
  return `£${(value).toLocaleString()}m`;
};

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-2 border border-gray-200 rounded shadow">
        <p className="font-bold">{label}</p>
        {payload.map((entry, index) => (
          <p key={index} style={{ color: entry.color }}>
            {entry.name}: {formatValue(entry.value)}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

const FinancialChart = ({ chartData }) => {
  const { type = 'line', data, xAxis, yAxis, title } = chartData;

  const renderLineChart = () => (
    <ResponsiveContainer width="100%" height={400}>
      <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey={xAxis} />
        <YAxis tickFormatter={formatValue} />
        <Tooltip content={<CustomTooltip />} />
        <Legend />
        <Line type="monotone" dataKey={yAxis} stroke="#0051A2" strokeWidth={2} name="Value" />
      </LineChart>
    </ResponsiveContainer>
  );

  const renderBarChart = () => (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey={xAxis} />
        <YAxis tickFormatter={formatValue} />
        <Tooltip content={<CustomTooltip />} />
        <Legend />
        <Bar dataKey={yAxis} fill="#0051A2" name="Value" />
      </BarChart>
    </ResponsiveContainer>
  );

  const renderPieChart = () => (
    <ResponsiveContainer width="100%" height={400}>
      <PieChart>
        <Pie
          data={data}
          dataKey={yAxis}
          nameKey={xAxis}
          cx="50%"
          cy="50%"
          outerRadius={150}
          label={entry => `${entry[xAxis]}: ${formatValue(entry[yAxis])}`}
        >
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip content={<CustomTooltip />} />
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  );

  const renderAreaChart = () => (
    <ResponsiveContainer width="100%" height={400}>
      <AreaChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey={xAxis} />
        <YAxis tickFormatter={formatValue} />
        <Tooltip content={<CustomTooltip />} />
        <Legend />
        <Area type="monotone" dataKey={yAxis} fill="#0051A2" stroke="#0051A2" name="Value" />
      </AreaChart>
    </ResponsiveContainer>
  );

  const renderRadarChart = () => (
    <ResponsiveContainer width="100%" height={400}>
      <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
        <PolarGrid />
        <PolarAngleAxis dataKey={xAxis} />
        <PolarRadiusAxis tickFormatter={formatValue} />
        <Radar name="Value" dataKey={yAxis} stroke="#0051A2" fill="#0051A2" fillOpacity={0.6} />
        <Legend />
        <Tooltip content={<CustomTooltip />} />
      </RadarChart>
    </ResponsiveContainer>
  );

  const renderComposedChart = () => (
    <ResponsiveContainer width="100%" height={400}>
      <ComposedChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey={xAxis} />
        <YAxis tickFormatter={formatValue} />
        <Tooltip content={<CustomTooltip />} />
        <Legend />
        <Bar dataKey={yAxis} fill="#0051A2" name="Value" />
        <Line type="monotone" dataKey={yAxis} stroke="#ff7300" name="Trend" />
      </ComposedChart>
    </ResponsiveContainer>
  );

  const ChartComponents = {
    line: renderLineChart,
    bar: renderBarChart,
    pie: renderPieChart,
    area: renderAreaChart,
    radar: renderRadarChart,
    composed: renderComposedChart
  };

  const renderChart = ChartComponents[type] || renderLineChart;

  return (
    <div className="w-full p-4 bg-white rounded-lg shadow">
      <h3 className="text-lg font-semibold mb-4 text-center text-gray-800">{title}</h3>
      {renderChart()}
      <div className="mt-4">
        <h4 className="font-semibold">Values:</h4>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
          {data.map((item, index) => (
            <div key={index} className="text-sm">
              {item[xAxis]}: {formatValue(item[yAxis])}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FinancialChart;