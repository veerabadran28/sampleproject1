import streamlit as st
from datetime import datetime
import os
import json
import sys

# Add the project root directory to Python path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(project_root)

from src.services.bedrock_service import BedrockService
from src.ui.summary_analysis import SummaryAnalysisUI
from src.ui.admin_interface import AdminUI

# UI Configuration
MAIN_UI_CONFIG = """
<style>
div.block-container {padding-top: 1rem !important;}
div.stImage {margin: 0 !important; padding: 0 !important;}
header {visibility: hidden;}
#MainMenu {visibility: hidden;}
footer {visibility: hidden;}
[data-testid="stToolbar"] {display: none;}
section[data-testid="stSidebar"] {display: none;}

.header {
    background-color: #0051A2;
    padding: 1rem;
    border-radius: 0;
    margin: 3 -4rem 2rem -4rem;
    padding: 1rem 4rem;
}

.search-container {
    display: flex;
    gap: 1rem;
    margin-top: 1rem;
}

.search-input {
    flex: 1;
    padding: 0.5rem;
    border: none;
    border-radius: 4px;
}

.search-button {
    background: #003D82;
    color: white;
    border: none;
    padding: 0.5rem 2rem;
    border-radius: 4px;
    cursor: pointer;
}

.stButton>button {
    background-color: #0051A2;
    color: white;
    border: none;
    border-radius: 4px;
    padding: 8px 16px;
    cursor: pointer;
}
</style>
"""

def load_configs():
    """Load common and bank-specific configurations."""
    try:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        config_dir = os.path.join(base_dir, 'config')
        
        # Load common config
        common_config_path = os.path.join(config_dir, 'common_config.json')
        if not os.path.exists(common_config_path):
            raise FileNotFoundError("Common config file not found")
            
        with open(common_config_path, 'r', encoding='utf-8') as f:
            common_config = json.load(f)
        
        # Load bank configs
        bank_configs = {}
        banks_dir = os.path.join(config_dir, 'banks')
        
        # Default placeholder config
        placeholder_config = {
            "bank_info": {
                "name": "",
                "logo_url": "",
                "implementation_status": "pending"
            }
        }
        
        # Create placeholder configs for all banks in working_summary_tabs
        working_summary_tabs = common_config['tabs_config']['working_summary_tabs']
        for bank_name in working_summary_tabs:
            bank_id = bank_name.lower().replace(' ', '_').replace('(', '').replace(')', '')
            bank_configs[bank_id] = placeholder_config.copy()
            bank_configs[bank_id]['bank_info']['name'] = bank_name
        
        # Load actual configs where available
        for file in os.listdir(banks_dir):
            if file.endswith('_config.json'):
                bank_id = file.replace('_config.json', '')
                config_path = os.path.join(banks_dir, file)
                
                try:
                    with open(config_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if content.strip():
                            bank_configs[bank_id] = json.loads(content)
                            bank_configs[bank_id]['bank_info']['implementation_status'] = 'active'
                except Exception as e:
                    st.warning(f"Could not load config for {bank_id}: {str(e)}")
                    continue
                    
        return common_config, bank_configs
        
    except Exception as e:
        st.error(f"Error loading configurations: {str(e)}")
        st.error(f"Current working directory: {os.getcwd()}")
        raise

def initialize_services(common_config):
    try:
        bedrock_service = BedrockService(common_config['model_config'])
        return bedrock_service
    except Exception as e:
        st.error(f"Error initializing services: {str(e)}")
        raise

def render_main_cards(cards_config):
    """Render main navigation cards."""
    col1, col2, col3, col4 = st.columns(4)
    
    # Update CSS for uniform card sizing and layout
    st.markdown("""
        <style>
        .item-card {
            background-color: white;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 1rem;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            height: 150px;  /* Fixed height for all cards */
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        
        .item-card h3 {
            margin: 0;
            padding: 0;
            font-size: 1.2rem;
            margin-bottom: 0.5rem;
        }
        
        .item-card p {
            margin: 0;
            padding: 0;
            font-size: 0.9rem;
            color: #666;
            flex-grow: 1;
        }

        .item-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        
        .sub-card {
            background-color: #f8f9fa;
            padding: 1.2rem;
            border-radius: 6px;
            margin-top: 0.5rem;
        }
        </style>
    """, unsafe_allow_html=True)
    
    for i, (title, data) in enumerate(cards_config.items()):
        with [col1, col2, col3, col4][i % 4]:
            form_key = f"form_{data['view']}_{i}"
            with st.form(key=form_key):
                st.markdown(
                    f"""
                    <div class="item-card">
                        <div>
                            <h3>{data['icon']} {title}</h3>
                            <p>{data['description']}</p>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
                if st.form_submit_button("Click Here!", use_container_width=True):
                    st.session_state.current_view = data['view']
                    st.rerun()

def main():
    st.set_page_config(
        page_title="Competitor Analysis",
        layout="wide",
        page_icon="🏦",
        initial_sidebar_state="collapsed",
        menu_items=None
    )

    try:
        # Load configurations
        common_config, bank_configs = load_configs()
        
        # Initialize services
        bedrock_service = initialize_services(common_config)

        # Apply UI styling
        st.markdown(MAIN_UI_CONFIG, unsafe_allow_html=True)

        # Initialize session state
        if 'current_view' not in st.session_state:
            st.session_state.current_view = 'main'

        # Render Barclays logo at the top-left corner
        barclays_logo_url = common_config.get("app_config", {}).get("barclays_logo_url", "")
        if barclays_logo_url:
            st.markdown(f"""
                <style>
                    .logo-container {{
                        display: flex;
                        align-items: center;
                        justify-content: flex-start;
                        padding: 0;
                        margin: 0;
                        top: 0;
                        left: 0;
                        margin-bottom: 10px;
                    }}
                    body {{
                        margin-top: 0 !important;
                        padding-top: 0 !important;
                    }}
                </style>
                <div class="logo-container">
                    <img src="{barclays_logo_url}" alt="Barclays Logo" style="height: 25px;" />
                </div>
            """, unsafe_allow_html=True)
        else:
            st.warning("Barclays logo URL is missing in the configuration.")

        # Render header below the logo
        st.markdown("""
            <div class="header">
                <h1 style="color: white; margin-bottom: 1rem;">Welcome to Competitor Analysis, Veerabadran</h1>
                <div class="search-container">
                    <input type="text" class="search-input" placeholder="What can we help you with today?">
                    <button class="search-button">Search</button>
                </div>
            </div>
        """, unsafe_allow_html=True)
        
        # Initialize session state for year and period if not exists
        if 'selected_year' not in st.session_state:
            st.session_state.selected_year = 2024
        if 'selected_period' not in st.session_state:
            st.session_state.selected_period = "Quarter 3"

        col1, col2 = st.columns(2)

        with col1:
            # Get the current year
            current_year = datetime.now().year
            # Create a range of 10 years from current year
            year_options = list(range(current_year, current_year - 10, -1))
            
            st.session_state.selected_year = st.selectbox(
                "Select Year",
                options=year_options,
                index=year_options.index(st.session_state.selected_year) if st.session_state.selected_year in year_options else 0
            )
            
        with col2:
            st.session_state.selected_period = st.selectbox(
                "Select Period", 
                options=["Quarter 1", "Quarter 2", "Quarter 3", "Quarter 4"],
                index=["Quarter 1", "Quarter 2", "Quarter 3", "Quarter 4"].index(st.session_state.selected_period)
            )

        # Main content routing
        if st.session_state.current_view == 'main':
            render_main_cards(common_config.get('app_config', {}).get('cards', {}))
        elif st.session_state.current_view == 'summary_analysis':
            summary_ui = SummaryAnalysisUI(
                common_config=common_config,
                bank_configs=bank_configs,
                bedrock_service=bedrock_service
            )
            summary_ui.render()
        elif st.session_state.current_view == 'admin':
            admin_ui = AdminUI(
                common_config=common_config,
                bank_configs=bank_configs
            )
            admin_ui.render()

    except Exception as e:
        st.error(f"Application error: {str(e)}")
        st.error("Please check the configuration and try again.")

if __name__ == "__main__":
    main()