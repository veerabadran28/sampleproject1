import streamlit as st
from typing import List, Dict

class ChatBot:
    def __init__(self):
        self.default_responses = {
            "greeting": ["hello", "hi", "hey", "greetings"],
            "farewell": ["goodbye", "bye", "see you", "cya"],
            "thanks": ["thank", "thanks", "appreciate"]
        }
    
    def get_response(self, message: str) -> Dict:
        """Generate response based on user input."""
        message = message.lower().strip()
        
        if any(word in message for word in self.default_responses["greeting"]):
            return {
                "response": "Hello! How can I help you today?",
                "type": "greeting"
            }
        elif any(word in message for word in self.default_responses["farewell"]):
            return {
                "response": "Goodbye! Have a great day!",
                "type": "farewell"
            }
        elif any(word in message for word in self.default_responses["thanks"]):
            return {
                "response": "You're welcome! Is there anything else I can help you with?",
                "type": "thanks"
            }
        else:
            return {
                "response": "I understand you're asking about that. How can I assist you further?",
                "type": "general"
            }

def initialize_session_state():
    """Initialize session state variables."""
    if "messages" not in st.session_state:
        st.session_state.messages = []
    if "user_input" not in st.session_state:
        st.session_state.user_input = ""

def main():
    st.set_page_config(page_title="Chatbot", page_icon="🤖", layout="wide")
    
    # Initialize session state
    initialize_session_state()
    
    # Initialize chatbot
    chatbot = ChatBot()

    # Apply custom CSS
    st.markdown("""
        <style>
        .stApp {
            background-color: #f0f2f5;
        }
        
        .chat-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin: 0 auto;
            max-width: 800px;
            height: 600px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }
        
        .chat-header {
            background-color: #075E54;
            color: white;
            padding: 1rem;
            font-weight: bold;
        }
        
        .chat-message-container {
            flex-grow: 1;
            overflow-y: auto;
            padding: 1rem;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            background-color: #f0f2f5;
            height: calc(100% - 130px);
        }
        
        .message {
            padding: 0.75rem 1rem;
            border-radius: 15px;
            max-width: 75%;
            word-wrap: break-word;
        }
        
        .user-message {
            background-color: #DCF8C6;
            align-self: flex-end;
            border-bottom-right-radius: 5px;
        }
        
        .bot-message {
            background-color: white;
            align-self: flex-start;
            border-bottom-left-radius: 5px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
        }
        
        .chat-input {
            padding: 1rem;
            background-color: white;
            border-top: 1px solid #ddd;
        }
        
        /* Hide Streamlit components */
        #MainMenu {visibility: hidden;}
        footer {visibility: hidden;}
        header {visibility: hidden;}
        
        /* Custom scrollbar */
        .chat-message-container::-webkit-scrollbar {
            width: 6px;
        }
        
        .chat-message-container::-webkit-scrollbar-track {
            background: transparent;
        }
        
        .chat-message-container::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 3px;
        }
        
        .chat-message-container::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        
        /* Style Streamlit elements */
        .stTextInput > div > div > input {
            background-color: white;
        }
        .stTextInput > div {
            padding: 0;
        }
        .stTextInput > label {
            display: none;
        }
        </style>
    """, unsafe_allow_html=True)

    # Create columns to center the chat container
    col1, col2, col3 = st.columns([1, 3, 1])
    
    with col2:
        # Main chat interface
        with st.container():
           
            
            # Header
            st.markdown('<div class="chat-header">💬 Chatbot</div>', unsafe_allow_html=True)
             # Chat container with all elements
            st.markdown('<div class="chat-container">', unsafe_allow_html=True)
            # Messages area
            # with st.container():
            st.markdown('<div class="chat-message-container">', unsafe_allow_html=True)
                
                # Display chat messages
            for message in st.session_state.messages:
                if message["role"] == "user":
                    st.markdown(
                        f'<div class="message user-message">{message["content"]}</div>',
                        unsafe_allow_html=True
                   )
                else:
                    st.markdown(
                        f'<div class="message bot-message">{message["content"]}</div>',
                        unsafe_allow_html=True
                    )
                st.markdown('</div>', unsafe_allow_html=True)
            
            # Input area
            # with st.container():
            st.markdown('<div class="chat-input">', unsafe_allow_html=True)
                
            def submit():
                if st.session_state.user_input.strip():
                    user_message = st.session_state.user_input
                        
                    # Add user message to chat history
                    st.session_state.messages.append({
                            "role": "user",
                            "content": user_message
                    })
                        
                        # Get bot response
                    response = chatbot.get_response(user_message)
                        
                        # Add bot response to chat history
                    st.session_state.messages.append({
                            "role": "assistant",
                            "content": response["response"]
                    })
                        
                        # Clear input
                    st.session_state.user_input = ""
                
            st.text_input(
                "Type your message:",
                key="user_input",
                on_change=submit,
                value=st.session_state.user_input
            )
                
            st.markdown('</div>', unsafe_allow_html=True)
            
        st.markdown('</div>', unsafe_allow_html=True)

if __name__ == "__main__":
    main()