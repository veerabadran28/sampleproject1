import streamlit as st
import pandas as pd
import json
import plotly.graph_objects as go
from typing import Dict, List, Any, Optional
import os
from src.services.s3_service import S3Service

class DashboardUI:
    def __init__(self, common_config: Dict):
        """Initialize DashboardUI with configuration."""
        self.common_config = common_config
        self.dashboard_config = self._load_dashboard_config()
        self.driver_values = st.session_state.get('driver_values', {})
        self.s3_service = S3Service(common_config['s3_config'])
        
        # Initialize configurations
        self.data_config = self.dashboard_config['data_config']
        self.viz_config = self.dashboard_config['visualization_config']
        self.metrics_config = self.dashboard_config['metrics_config']
        self.chart_config = self.dashboard_config['chart_config']
        self.layout_config = self.dashboard_config['layout_config']
        
        print(st.session_state.get('driver_values', {}))

    def _load_dashboard_config(self) -> Dict:
        """Load dashboard configuration from file."""
        try:
            config_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                'config',
                'dashboard_config.json'
            )
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            st.error(f"Error loading dashboard config: {str(e)}")
            return {}

    def _extract_numeric_value(self, value_str: str) -> float:
        """Extract numeric value from string, handling parentheses for negative values."""
        try:
            if isinstance(value_str, (int, float)):
                return float(value_str)
            
            if not value_str or value_str == '':
                return 0.0
                
            value_str = str(value_str).replace(',', '')
            if '(' in value_str and ')' in value_str:
                return -float(value_str.replace('(', '').replace(')', '').replace('%', ''))
            return float(value_str.replace('%', ''))
        except:
            return 0.0

    def _get_period_value(self, period_type: str, is_current: bool) -> str:
        """Get period value from driver values based on configuration."""
        try:
            period_config = self.dashboard_config['data_config']['period_config'][period_type]
            period_key = 'current' if is_current else 'prior'
            driver_key = period_config[period_key]['driver_key']
            return self.driver_values.get(driver_key, '')
        except Exception as e:
            st.error(f"Error getting period value: {str(e)}")
            return ''

    def _load_bank_data(self, bank_config: Dict, period_type: str) -> Optional[Dict]:
        """Load data for a specific bank from S3."""
        try:
            # Get file path from config
            file_path = bank_config['full_path'].format(
                year=st.session_state.get('driver_year'),
                period=st.session_state.get('driver_period')
            )
            
            # Load data from S3
            content = self.s3_service.get_document_content(file_path)
            if content:
                data = json.loads(content.decode(
                    self.dashboard_config['data_config']['file_config']['encoding']
                ))
                if isinstance(data, dict) and 'content' in data:
                    return json.loads(data['content'])
                return data
                
        except Exception as e:
            st.error(f"Error loading data for {bank_config['display_name']}: {str(e)}")
        return None
    
    def _process_bank_metrics(self, data: Dict, bank_name: str, period_type: str) -> Dict:
        """Process metrics for a bank."""
        try:
            data_array = data.get('data', [])
            header_row = data_array[0]
            column_map = {col: idx for idx, col in enumerate(header_row)}
            
            metrics = {'Bank': bank_name}
            metrics_to_process = self.dashboard_config['data_config']['column_mappings']['metrics']
            periods = self.dashboard_config['data_config']['column_mappings']['periods'][period_type]
            
            for row in data_array[1:]:
                if len(row) > 0:
                    metric_name = row[0]
                    if metric_name in metrics_to_process:
                        for period in periods:
                            value = self._get_value_from_row(row, period, column_map)
                            metrics[f"{metric_name}_{period}"] = self._extract_numeric_value(value)
                            
                        # Get variance if available
                        for var_col in self.dashboard_config['data_config']['column_mappings']['variance']:
                            var_value = self._get_value_from_row(row, var_col, column_map)
                            if var_value:
                                metrics[f"{metric_name}_Var"] = self._extract_numeric_value(var_value)
                                break
            
            return metrics
            
        except Exception as e:
            st.error(f"Error processing metrics for {bank_name}: {str(e)}")
            return None
        
    def _process_data(self, period_type: str) -> pd.DataFrame:
        """Process data for given period type."""
        try:
            processed_data = []
            bank_configs = self.dashboard_config['data_config']['bank_configs'][period_type]['banks']
            
            for bank_config in bank_configs:
                data = self._load_bank_data(bank_config, period_type)
                if data:
                    metrics = self._process_bank_metrics(
                        data,
                        bank_config['display_name'],
                        period_type
                    )
                    if metrics:
                        processed_data.append(metrics)
                        
            return pd.DataFrame(processed_data)
            
        except Exception as e:
            st.error(f"Error processing {period_type} data: {str(e)}")
            return pd.DataFrame()

    def _get_value_from_row(self, row: List, column_name: str, column_map: Dict) -> Any:
        """Safely get value from row using column mapping."""
        if column_name in column_map and column_map[column_name] < len(row):
            return row[column_map[column_name]]
        return None

    def _format_value(self, value: float, chart_config: Dict) -> str:
        """Format value based on metric type from config."""
        try:
            metric = chart_config['metric']
            # Find the metric config
            metric_config = next(
                (m for m in self.dashboard_config['metrics_config']['half_year_metrics'] 
                 if m['source_field'] == metric),
                next(
                    (m for m in self.dashboard_config['metrics_config']['quarter_metrics'] 
                     if m['source_field'] == metric),
                    None
                )
            )
            
            if not metric_config:
                return str(value)
                
            metric_type = metric_config['type']
            format_config = self.dashboard_config['metrics_config']['format_config'][metric_type]
            
            if metric_type == 'currency':
                formatted = f"{format_config['prefix']}{value:,.{format_config['decimal_places']}f}"
                if format_config.get('suffix'):
                    formatted += format_config['suffix']
            elif metric_type == 'percentage':
                formatted = f"{value:.{format_config['decimal_places']}f}{format_config['suffix']}"
            else:
                formatted = f"{value:.{format_config['decimal_places']}f}"
                
            return formatted
            
        except Exception as e:
            st.error(f"Error formatting value for {chart_config['metric']}: {str(e)}")
            return str(value)

    def _calculate_metric_change(self, metric_config: Dict, current_value: float, prior_value: float) -> float:
        """Calculate the change between current and prior values."""
        try:
            if prior_value == 0:
                return 0
                
            if metric_config['type'] == 'percentage':
                # For percentage metrics like NIM and CIR, use absolute difference
                return current_value - prior_value
            else:
                # For other metrics, use percentage change
                return ((current_value - prior_value) / prior_value) * 100
        except:
            return 0
        
    def _format_metric_value(self, value: float, metric_config: Dict) -> str:
        """Format metric value based on configuration."""
        try:
            format_config = self.dashboard_config['metrics_config']['format_config']
            
            if metric_config['type'] == 'currency':
                currency_config = format_config['currency']
                formatted = f"{currency_config['prefix']}{value:,.{currency_config['decimal_places']}f}"
                if currency_config.get('suffix'):
                    formatted += currency_config['suffix']
                return formatted
            elif metric_config['type'] == 'percentage':
                pct_config = format_config['percentage']
                return f"{value:.{pct_config['decimal_places']}f}{pct_config['suffix']}"
            else:
                num_config = format_config['number']
                return f"{value:.{num_config['decimal_places']}f}"
                
        except Exception as e:
            st.error(f"Error formatting metric value: {str(e)}")
            return str(value)
    
    def _calculate_market_share(self, df: pd.DataFrame, metric_name: str, period: str) -> pd.Series:
        """Calculate market share for given metric and period."""
        try:
            total = df[f"{metric_name}_{period}"].sum()
            if total > 0:
                return (df[f"{metric_name}_{period}"] / total * 100).round(1)
            return pd.Series([0] * len(df))
        except Exception as e:
            st.error(f"Error calculating market share: {str(e)}")
            return pd.Series([0] * len(df))
           
    def _create_metric_card(self, metric_config: Dict, df: pd.DataFrame, period_type: str):
        """Create a metric card based on configuration."""
        try:
            # Get reference bank from config
            reference_bank = self.dashboard_config['data_config']['reference_bank']
            bank_data = df[df['Bank'] == reference_bank].iloc[0]
            
            # Get periods from config
            periods = self.dashboard_config['data_config']['column_mappings']['periods'][period_type]
            current_period, prior_period = periods[0], periods[1]
            
            source_field = metric_config['source_field']
            
            if metric_config.get('calculation') == 'market_share':
                # Calculate market shares for both periods
                current_shares = self._calculate_market_share(df, source_field, current_period)
                prior_shares = self._calculate_market_share(df, source_field, prior_period)
                
                # Get reference bank's market shares
                current_value = current_shares[df['Bank'] == reference_bank].iloc[0]
                prior_value = prior_shares[df['Bank'] == reference_bank].iloc[0]
                
                # Format value and calculate change
                formatted_value = f"{current_value:.1f}%"
                change = current_value - prior_value
            else:
                # Get values
                current_value = bank_data.get(f"{source_field}_{current_period}", 0)
                prior_value = bank_data.get(f"{source_field}_{prior_period}", 0)
                
                # Format value
                formatted_value = self._format_metric_value(current_value, metric_config)
                
                # Calculate change
                if metric_config['type'] == 'percentage':
                    change = current_value - prior_value
                else:
                    change = ((current_value - prior_value) / prior_value * 100) if prior_value != 0 else 0
            
            # Create metric
            st.metric(
                label=metric_config['name'],
                value=formatted_value,
                delta=f"{change:+.2f}%",
                help=metric_config.get('description', '')
            )
            
        except Exception as e:
            st.error(f"Error creating metric card for {metric_config['name']}: {str(e)}")

    def _update_chart_layout(self, fig: go.Figure, chart_config: Dict) -> None:
        """Update chart layout with consistent styling."""
        layout_config = {
            'title': chart_config['title'],
            'height': self.dashboard_config['visualization_config']['chart_height'],
            'template': self.dashboard_config['visualization_config']['template'],
            'paper_bgcolor': 'white',
            'plot_bgcolor': '#f8f9fa',
            'margin': dict(t=50, b=50, l=50, r=50),
            'font': dict(size=12),
            'xaxis': dict(
                title=chart_config['axis_config']['x_title'],
                gridcolor='#e9ecef'
            ),
            'yaxis': dict(
                title=chart_config['axis_config']['y_title'],
                gridcolor='#e9ecef'
            ),
            'showlegend': True,
            'legend': dict(
                bgcolor='rgba(255,255,255,0.8)',
                bordercolor='#e9ecef',
                borderwidth=1
            )
        }
        
        fig.update_layout(**layout_config)

    def _create_bar_chart(self, df: pd.DataFrame, chart_config: Dict, period_type: str) -> go.Figure:
        """Create a bar chart with consistent styling."""
        try:
            fig = go.Figure()
            periods = self.dashboard_config['data_config']['column_mappings']['periods'][period_type]
            colors = self.dashboard_config['visualization_config']['period_colors'][period_type]
            
            for period, color in zip(periods, [colors['current'], colors['prior']]):
                values = df[f"{chart_config['metric']}_{period}"]
                fig.add_trace(go.Bar(
                    name=period,
                    x=df['Bank'],
                    y=values,
                    text=[self._format_chart_value(v, chart_config) for v in values],
                    textposition='auto',
                    marker_color=color,
                    marker=dict(opacity=0.9)  # Slight transparency
                ))
                
            # Apply consistent styling
            self._update_chart_layout(fig, chart_config)
            fig.update_layout(barmode='group')
            
            return fig
            
        except Exception as e:
            st.error(f"Error creating bar chart: {str(e)}")
            return None

    def _create_line_chart(self, df: pd.DataFrame, chart_config: Dict, period_type: str) -> go.Figure:
        """Create a line chart with consistent styling."""
        try:
            fig = go.Figure()
            periods = self.dashboard_config['data_config']['column_mappings']['periods'][period_type]
            
            for bank in df['Bank'].unique():
                bank_data = df[df['Bank'] == bank]
                color = self.dashboard_config['visualization_config']['colors'].get(
                    bank,
                    self.dashboard_config['visualization_config']['default_color']
                )
                
                values = [bank_data[f"{chart_config['metric']}_{period}"].iloc[0] for period in periods]
                fig.add_trace(go.Scatter(
                    x=periods,
                    y=values,
                    name=bank,
                    mode='lines+markers+text',
                    text=[self._format_chart_value(v, chart_config) for v in values],
                    textposition='top center',
                    marker_color=color,
                    line=dict(width=2)
                ))
                
            # Apply consistent styling
            self._update_chart_layout(fig, chart_config)
            
            return fig
            
        except Exception as e:
            st.error(f"Error creating line chart: {str(e)}")
            return None

    def _create_pie_chart(self, df: pd.DataFrame, chart_config: Dict, period_type: str) -> go.Figure:
        """Create a pie chart with consistent styling."""
        try:
            fig = go.Figure()
            current_period = self.dashboard_config['data_config']['column_mappings']['periods'][period_type][0]
            
            if chart_config.get('use_percentage', False):
                values = self._calculate_market_share(df, chart_config['metric'], current_period)
            else:
                values = df[f"{chart_config['metric']}_{current_period}"]
            
            colors = [self.dashboard_config['visualization_config']['colors'].get(bank, 
                     self.dashboard_config['visualization_config']['default_color'])
                     for bank in df['Bank']]
            
            fig.add_trace(go.Pie(
                labels=df['Bank'],
                values=values,
                hole=chart_config.get('hole_size', 0),
                text=values,
                texttemplate="%{value:.1f}%",
                hovertemplate="%{label}<br>%{value:.1f}%<extra></extra>",
                textposition='inside',
                marker_colors=colors,
                opacity=0.9  # Set opacity directly on the trace
            ))
            
            # Apply consistent styling
            layout_config = {
                'title': chart_config['title'],
                'height': self.dashboard_config['visualization_config']['chart_height'],
                'template': self.dashboard_config['visualization_config']['template'],
                'paper_bgcolor': 'white',
                'plot_bgcolor': '#f8f9fa',
                'margin': dict(t=50, b=50, l=50, r=50),
                'font': dict(size=12),
                'showlegend': True,
                'legend': dict(
                    bgcolor='rgba(255,255,255,0.8)',
                    bordercolor='#e9ecef',
                    borderwidth=1
                )
            }
            
            fig.update_layout(**layout_config)
            
            return fig
            
        except Exception as e:
            st.error(f"Error creating pie chart: {str(e)}")
            return None

    def _render_section(self, df: pd.DataFrame, section_type: str):
        """Render a complete section (metrics and charts)."""
        try:
            section_config = self.dashboard_config['layout_config']['sections'][section_type]
            
            # Render section title
            st.markdown(f"### {section_config['title']}")
            
            # Render metrics
            metrics_config = self.dashboard_config['metrics_config'][f'{section_type}_metrics']
            cols = st.columns(section_config['metrics_columns'])
            
            for col, metric_config in zip(cols, metrics_config):
                with col:
                    self._create_metric_card(metric_config, df, section_type)
            
            # Render charts
            for row in section_config['chart_rows']:
                cols = st.columns(len(row['columns']))
                for col, chart_id in zip(cols, row['columns']):
                    with col:
                        chart_config = next(
                            (chart for chart in self.dashboard_config['chart_config'][f'{section_type}_charts']
                             if chart['id'] == chart_id),
                            None
                        )
                        if chart_config:
                            chart_func = getattr(self, f"_create_{chart_config['type']}_chart")
                            fig = chart_func(df, chart_config, section_type)
                            if fig:
                                # Always use container width as True (best for responsive layout)
                                st.plotly_chart(fig, use_container_width=True)
                                
        except Exception as e:
            st.error(f"Error rendering {section_type} section: {str(e)}")

    def _format_chart_value(self, value: float, chart_config: Dict) -> str:
        """Format value for chart display."""
        try:
            # Find the corresponding metric configuration
            metric_config = next(
                (m for m in self.dashboard_config['metrics_config']['half_year_metrics'] 
                 if m['source_field'] == chart_config['metric']),
                next(
                    (m for m in self.dashboard_config['metrics_config']['quarter_metrics'] 
                     if m['source_field'] == chart_config['metric']),
                    None
                )
            )
            
            if metric_config:
                return self._format_metric_value(value, metric_config)
            return str(value)
            
        except Exception as e:
            st.error(f"Error formatting chart value: {str(e)}")
            return str(value)
        
    def _create_chart(self, chart_name: str, chart_config: Dict, df: pd.DataFrame) -> go.Figure:
        """Create a chart based on configuration."""
        try:
            fig = go.Figure()
            metric = chart_config['metric']
            period_type = chart_config.get('period_type', 'half_year')
            
            current_period = self._get_period_value(period_type, True)
            prior_period = self._get_period_value(period_type, False)
            
            if chart_config['type'] == 'bar':
                for period in [current_period, prior_period]:
                    values = df[f"{metric}_{period}"]
                    fig.add_trace(go.Bar(
                        name=period,
                        x=df['Bank'],
                        y=values,
                        text=[self._format_chart_value(v, metric) for v in values],
                        textposition='auto',
                        textangle=0,  # Only apply textangle to bar charts
                        marker_color=self.viz_config['period_colors'][period_type][
                            'current' if period == current_period else 'prior'
                        ]
                    ))
                    
                fig.update_layout(barmode='group')
                
            elif chart_config['type'] == 'line':
                for bank in df['Bank']:
                    bank_data = df[df['Bank'] == bank].iloc[0]
                    y_values = [
                        bank_data[f"{metric}_{prior_period}"],
                        bank_data[f"{metric}_{current_period}"]
                    ]
                    fig.add_trace(go.Scatter(
                        x=[prior_period, current_period],
                        y=y_values,
                        name=bank,
                        text=[self._format_chart_value(v, metric) for v in y_values],
                        mode='lines+markers+text',
                        textposition='top center',
                        textfont=dict(size=12),
                        marker_color=self.viz_config['colors'].get(bank, 
                                   self.viz_config['default_color'])
                    ))
                    
            elif chart_config['type'] == 'pie':
                values = df[f"{metric}_{current_period}"]
                if chart_config.get('use_percentage', False):
                    values = (values / values.sum() * 100).round(1)
                
                fig.add_trace(go.Pie(
                    labels=df['Bank'],
                    values=values,
                    hole=chart_config.get('hole_size', 0),
                    text=[self._format_chart_value(v, metric) for v in values],
                    textposition='inside',
                    textinfo='label+text',
                    textfont=dict(size=12),
                    marker_colors=[self.viz_config['colors'].get(bank, 
                                 self.viz_config['default_color']) 
                                 for bank in df['Bank']]
                ))

            # Apply common layout settings
            layout_settings = {
                'title': chart_config['title'],
                'height': self.viz_config['chart_height'],
                'template': self.viz_config['template'],
                'showlegend': True,
                'margin': dict(t=50, b=50, l=50, r=50),
                'font': dict(size=12)
            }
            
            # Add axis titles if configured
            if 'axis_config' in chart_config:
                layout_settings.update({
                    'xaxis_title': chart_config['axis_config'].get('x_title'),
                    'yaxis_title': chart_config['axis_config'].get('y_title')
                })

            # Update only bar chart traces with textangle
            if chart_config['type'] == 'bar':
                fig.update_traces(textangle=0)

            fig.update_layout(**layout_settings)
            return fig
            
        except Exception as e:
            st.error(f"Error creating chart {chart_name}: {str(e)}")
            return None

    def render(self):
        """Render the complete dashboard."""
        try:
            # Apply custom styling
            st.markdown("""
                <style>
                /* Overall dashboard background */
                .stApp {
                    background-color: #f8f9fa;
                }
                
                /* Section styling */
                .section-header {
                    background-color: white;
                    padding: 1rem;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
                }
                
                /* Metric card styling */
                [data-testid="stMetric"] {
                    background-color: white;
                    padding: 1rem;
                    border-radius: 8px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
                }
                
                [data-testid="stMetricValue"] {
                    color: #0051A2;
                }
                
                /* Delta color styles */
                .stMetricDelta {
                    background-color: rgba(255, 255, 255, 0.8);
                    padding: 0.2rem 0.5rem;
                    border-radius: 4px;
                }
                
                /* Chart container styling */
                .stPlotlyChart {
                    background-color: white;
                    padding: 1rem;
                    border-radius: 8px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
                }
                
                /* Divider styling */
                hr {
                    margin: 2rem 0;
                    border: none;
                    border-top: 1px solid #e9ecef;
                }
                </style>
            """, unsafe_allow_html=True)
            
            # Process half-year data
            half_year_df = self._process_data('half_year')
            if not half_year_df.empty:
                self._render_section(half_year_df, 'half_year')
            
            # Add spacing between sections
            st.markdown(self.dashboard_config['layout_config']['spacing']['divider'])
            
            # Process quarterly data
            quarterly_df = self._process_data('quarter')
            if not quarterly_df.empty:
                self._render_section(quarterly_df, 'quarter')
            else:
                st.warning("No quarterly data available")
                
        except Exception as e:
            st.error(f"Error rendering dashboard: {str(e)}")
            
    def _load_banks_data(self) -> Dict:
        """Load data for all banks from S3."""
        banks_data = {}
        year = st.session_state.get('driver_year', '2024')
        period = st.session_state.get('driver_period', 'Q3')

        try:
            for bank, config in self.data_config['bank_files'].items():
                s3_path = config['full_path'].format(year=year, period=period)
                content = self.s3_service.get_document_content(s3_path)
                
                if content:
                    banks_data[bank] = json.loads(content.decode('utf-8'))
                else:
                    st.warning(f"No data found for {bank} at {s3_path}")
                    
        except Exception as e:
            st.error(f"Error loading bank data: {str(e)}")

        return banks_data